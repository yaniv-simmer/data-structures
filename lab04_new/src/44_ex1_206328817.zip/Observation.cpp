//
// Created by simme on 11/20/2022.
//

#include <iostream>
#include <sstream>
#include "Observation.h"
using namespace std;

Observation::Observation() {

    legal= false;
    name = new char[16];
    size = 0;
    values =nullptr;
}


Observation::Observation(int dim) {

    string input_name;
    cout << "Enter observation name:\n";


    getline(cin,input_name );


    name = input_name ;

    this->size = dim;

    values = new double [size];


    string input_line;
    cout << "Enter observation values:"<<endl;
    getline(cin , input_line);
    stringstream iss(input_line);

    string word;
    int i =0;
    while (iss >> word ) {


        values[i] = stod(word);
        i++;
    }
    legal= true;
    if(i!=size){
        delete(values);
        legal= false;
        std::cerr<<"Invalid observation.\n";

        return;
    }
}


string Observation::getName() {
    return (name);
}

void Observation::print() {
    if(legal== false){
        return;
    }
    cout<<name<<" = [";

    for(int i=0 ; i<size ; i++)
        cout<<" "<<values[i];
    cout<<"]"<<endl;
}

double* Observation::getValues() {
    return values;
}


bool Observation::isLeagal() {return legal;}