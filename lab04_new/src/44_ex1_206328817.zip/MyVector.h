//
// Created by simme on 11/20/2022.
//

#ifndef HW1_NEWNEW_MYVECTOR_H
#define HW1_NEWNEW_MYVECTOR_H

#include "Observation.h"

class MyVector {

public:
    explicit MyVector(int max_size);

    void add(Observation obsrv);

    Observation get();

    Observation geti(int index);

    void set(int index, Observation obsrv);

    void printExpectedValVec(int dim);

    void printCovarianceMatrix(int dim);

private:
    int curr_max_lenth;
    int obsrvs_num;
    int final_max_lenth;
    Observation *arr;

};


#endif //HW1_NEWNEW_MYVECTOR_H
