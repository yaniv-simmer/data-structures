//
// Created by simme on 11/20/2022.
//

#include <iostream>
#include <utility>
#include "MyVector.h"

using namespace std;

MyVector::MyVector(int max_size) {
    curr_max_lenth = 2;
    obsrvs_num = 0;
    final_max_lenth = max_size;
    arr = new Observation[2];

}

void MyVector::add(Observation obsrv) {
    if (obsrvs_num == final_max_lenth) {
        std::cerr<<"too many bservations";
    }
    if (obsrvs_num == curr_max_lenth) {
        Observation *temp = new Observation[obsrvs_num * 2];
        curr_max_lenth *= 2;
        for (int i = 0; i < obsrvs_num; i++) {
            temp[i] = arr[i];
        }
        delete[]arr;
        arr = temp;
    }
    for (int i = 0; i < obsrvs_num; ++i) {
        if (arr[i].getName()==obsrv.getName()){
            arr[i] = std::move(obsrv);
            return;
        }
    }
    arr[obsrvs_num] = std::move(obsrv);
    obsrvs_num++;
}


Observation MyVector::get() {

    cout << "Enter observation name:" << endl;

    string name;
    getline(cin, name);


    for (int i = 0; i < obsrvs_num; i++) {
        if (arr[i].getName() == name)
            return arr[i];
    }
    std::cerr<<"Invalid or nonexistent observation.\n";
    return {};
}

Observation MyVector::geti(int index) {
    return arr[index];
}


void MyVector::set(int index, Observation obsrv) {
    arr[index] = std::move(obsrv);
}

void MyVector::printExpectedValVec(int dim) {
    float res[dim];
    for (int i = 0; i < dim; i++) {
        res[i] = 0;
        for (int k = 0; k < obsrvs_num; k++) {
            res[i] += (float) ((1 / (float) obsrvs_num) * geti(k).getValues()[i]);
        }
    }
    cout << "mean = [";
    for (int j = 0; j < dim; j++) {
        cout << " " << res[j];
    }
    cout << "]" << endl;
}


void MyVector::printCovarianceMatrix(int dim) {
    if(obsrvs_num==0){
        std::cerr<<"Empty calculator.\n";
        return;
    }
    float res[dim];
    for (int i = 0; i < dim; i++) {
        res[i] = 0;
        for (int k = 0; k < obsrvs_num; k++) {
            res[i] += (float) ((1 / (float) obsrvs_num) * geti(k).getValues()[i]);
        }
    }

    float mtrx[dim][dim];
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            mtrx[i][j] = 0;
            for (int k = 0; k < obsrvs_num; k++) {
                mtrx[i][j] += (float) (geti(k).getValues()[i] - res[i]) * (float) (geti(k).getValues()[j] - res[j]);
            }

        }
    }
    cout << "cov = [" << endl;
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            if (obsrvs_num > 1) {
                cout << " " << (1 / ((float) obsrvs_num - 1)) * mtrx[i][j];
            }
            if(obsrvs_num==1){
                cout << " " << (1 / ((float) obsrvs_num)) * mtrx[i][j];
            }
        }
        cout << "\n";
    }
    cout << "]";
}