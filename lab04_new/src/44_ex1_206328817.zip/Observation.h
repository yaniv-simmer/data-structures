//
// Created by simme on 11/20/2022.
//

#ifndef HW1_NEWNEW_OBSERVATION_H
#define HW1_NEWNEW_OBSERVATION_H


#include <string>
using namespace std;


class Observation {
public:
    Observation();

    explicit Observation(int dim);

    string getName();

    void print();

    double* getValues();

    bool isLeagal();

private:
    string name;
    int size;
    double *values;
    bool legal;
};


#endif //HW1_NEWNEW_OBSERVATION_H
