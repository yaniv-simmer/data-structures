#include <iostream>
#include "MyVector.h"
#include "Observation.h"


int main(int argc, char *argv[]) {

    if (argc != 3)
        perror("Invalid arguments <int> <int>.\n");

    MyVector *vector = new MyVector(stoi(argv[2]));


    cout << "[1] New observation\n"
            "[2] Print observation\n"
            "[3] Expected value vector\n"
            "[4] Covariance matrix\n"
            "[5] Exit" << endl;
    string input;


    while (true) {

        getline(cin, input);


        switch (stoi(input)) {
            case 1: {
                Observation *observ = new Observation((stoi(argv[1])));
                if (observ->isLeagal()) {
                    vector->add(*observ);
                }
                break;
            }
            case 2: {
                vector->get().print();
                break;
            }
            case 3: {
                vector->printExpectedValVec(stoi(argv[1]));
                break;
            }
            case 4: {
                vector->printCovarianceMatrix(stoi(argv[1]));

                break;
            }
            case 5: {
                exit(1);
            }
            case 6: {
                cout << "6666666\n";
                vector->geti(0).print();
                vector->geti(1).print();



                break;
            }
        }

    }


}
